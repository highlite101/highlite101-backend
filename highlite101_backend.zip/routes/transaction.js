const express = require("express");
const router = express.Router();
const Transaction = require("../models/Transaction");

router.post("/deposit", async (req, res) => {
    const { userId, amount } = req.body;
    try {
        const newTransaction = new Transaction({ userId, amount, type: "deposit" });
        await newTransaction.save();
        res.status(201).json({ message: "Deposit recorded" });
    } catch (err) {
        res.status(500).json({ error: "Deposit failed" });
    }
});

router.post("/withdraw", async (req, res) => {
    const { userId, amount } = req.body;
    try {
        const newTransaction = new Transaction({ userId, amount, type: "withdraw" });
        await newTransaction.save();
        res.status(201).json({ message: "Withdrawal recorded" });
    } catch (err) {
        res.status(500).json({ error: "Withdrawal failed" });
    }
});

module.exports = router;
